I probably don't need to put anything here.  Nobody reads readme files anyway right?

Oh I guess you did.

This is embarrassing.

Uhhh... it's a game that is good!  Yeah!

Err... 

This is the windows version?
SO basically I don't think you can, um, run it on platforms that aren't windows?
You might get an annoying Windows Defender popup, just click more info and run anyway.  This is a GameMaker game, not a virus.

Controls:

M key to toggle music playing.
ESC to exit game.

As platforming slime:
Left/Right Arrow Keys or A/D Keys to?? move left/right.

Space-bar to punch.
As a pong paddle:
Up/Down Arrow Keys or W/S keys to move up and down.
Left/Right Arrow Keys or A/D Keys to? fire slime balls.

Space-bar to eject from the paddle into the platforming slime.



